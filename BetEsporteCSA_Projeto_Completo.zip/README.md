# BetEsporteCSA
Plataforma completa de apostas com integração PagBank.